a,b,*c=open(0).read().split()
f="p1000a.dat"
with open(f,"w") as f1:
    f1.write("{} {}\n".format(a,b))
    for i in range(1000*1000):
        f1.write("{} ".format(c[i]))
