class Car {
    int num;
    double gas;
    double mileage;

    void show() {
        System.out.println("車のナンバーは" + num + "です");
        System.out.println("ガソリン量は" + gas + "です");
        System.out.println("走行距離は" + mileage + "です");
    }

    int getNum() {
        System.out.println("車のナンバーを調べました");
        return num;
    }

    double getGas() {
        System.out.println("ガソリン量を調べました");
        return gas;
    }

    double getMileage() {
        System.out.println("走行距離を調べました");
        return mileage;
    }

    void setNumGasMileage(int n, double g, double m) {
        System.out.println("車のナンバーを" + n + "に、エンジン量を" + g + "に、走行距離を" + m + "にしました");
        num = n;
        gas = g;
        mileage = m;
    }
}

class Kadai04_1 {
    public static void main(String[] av) {
        Car car1 = new Car();
        car1.num = 1234;
        car1.gas = 20.5;
        car1.mileage = 10000;

        Car car2 = new Car();
        car2.num = 2345;
        car2.gas = 30.5;
        car2.mileage = 50000;

        System.out.println("car1.num:" + car1.num + " car1.gas:" + car1.gas + " car1.mileage:" + car1.mileage);
        System.out.println("car2.num:" + car2.num + " car2.gas:" + car2.gas + " car2.mileage:" + car2.mileage);
    }
}

class Kadai04_2 {
    public static void main(String[] av) {
        Car car1 = new Car();
        car1.setNumGasMileage(1234, 20.5, 10000);
        car1.show();

    }
}