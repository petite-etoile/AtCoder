//import java.lang.Math;
class Triangle {
    double a, b, c;

    void setA(double v) {
        a = v;
    }

    void setB(double v) {
        b = v;
    }

    void setC(double v) {
        c = v;
    }

    void show() {
        System.out.println("３辺の長さは：" + a + "," + b + "," + c + "です");
    }

    double area() {
        double max = Math.max(a, Math.max(b, c));
        if (max < (a + b + c) - max) {
            double s = (a + b + c) / 2;
            double ans = Math.sqrt(s * (s - a) * (s - b) * (s - c));
            return ans;
        } else {
            System.out.println("三角形は作れません");
            return 0;
        }
    }
}

class Kadai04_3 {
    public static void main(String[] av) {
        Triangle tri1 = new Triangle();
        tri1.setA(1);
        tri1.setB(1);
        tri1.setC(1);
        tri1.show();
        double t1_area = tri1.area();
        if (t1_area > 0) {
            System.out.println("t1.area()=" + t1_area);
        }

        Triangle tri2 = new Triangle();
        tri2.setA(3);
        tri2.setB(4);
        tri2.setC(5);
        tri2.show();
        double t2_area = tri2.area();
        if (t2_area > 0) {
            System.out.println("t2.area()=" + t2_area);
        }

        Triangle tri3 = new Triangle();
        tri3.setA(1);
        tri3.setB(2);
        tri3.setC(4);
        tri3.show();
        double t3_area = tri3.area();
        if (t3_area > 0) {
            System.out.println("t3.area()=" + t3_area);
        }
    }
}

class Tri2d {
    double Ax, Ay, Bx, By, Cx, Cy;

    void setA(double x, double y) {
        Ax = x;
        Ay = y;
    }

    void setB(double x, double y) {
        Bx = x;
        By = y;
    }

    void setC(double x, double y) {
        Cx = x;
        Cy = y;
    }

    void showA() {
        System.out.println("Aの座標:" + Ax + "," + Ay);
    }

    void showB() {
        System.out.println("Bの座標:" + Bx + "," + By);
    }

    void showC() {
        System.out.println("Cの座標:" + Cx + "," + Cy);
    }

    double area() {
        double ab = Math.sqrt(Math.abs((Ax - Bx) * (Ax - Bx) + (Ay - By) * (Ay - By)));
        double bc = Math.sqrt(Math.abs((Cx - Bx) * (Cx - Bx) + (Cy - By) * (Cy - By)));
        double ac = Math.sqrt(Math.abs((Ax - Cx) * (Ax - Cx) + (Ay - Cy) * (Ay - Cy)));
        double max = Math.max(ab, Math.max(bc, ac));
        if (max < (ab + bc + ac) - max) {
            double s = (ab + bc + ac) / 2;
            double ans = Math.sqrt(s * (s - ab) * (s - bc) * (s - ac));
            return ans;
        } else {
            System.out.println("三角形は作れません");
            return 0;
        }
    }
}

class Kadai04_4 {
    public static void main(String[] av) {
        Tri2d t = new Tri2d();
        t.setA(1, 1);
        t.setB(10, 6);
        t.setC(3, 10);
        double t_area = t.area();
        if (t_area > 0) {
            System.out.println("t.are()=" + t_area);
        }
        t.showA();
        t.showB();
        t.showC();
    }
}