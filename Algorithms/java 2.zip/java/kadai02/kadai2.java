import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;

//17D8101002F OnoTakaki 4/17
class DataTypeSample {
    public static void main(String[] av) {
        byte b = (byte) (1 << 7);
        short s = (short) (1 << 15);
        int i = (1 << 31);
        long l = (1L << 63);
        float f = 1.0e-45F;
        double d = 1.4e-323;
        char c = '情';
        System.out.println("b=" + b);
        System.out.println("s=" + s);
        System.out.println("i=" + i);
        System.out.println("l=" + l);
        System.out.println("f=" + f);
        System.out.println("d=" + d);
        System.out.println("c=" + c);
        System.out.println("c=" + Integer.toHexString((int) c));
        System.out.println("c=\u60c5");
    }
}

class DataTypeMaximum {
    public static void main(String[] av) {
        byte b = (byte) (1 << 7 - 1);
        short s = (short) (1 << 15 - 1);
        int i = (1 << 31) - 1;
        long l = (1L << 63) - 1;
        System.out.println("b=" + b);
        System.out.println("s=" + s);
        System.out.println("i=" + i);
        System.out.println("l=" + l);

    }
}
/*
 * McDonalds:kadai02 takaki$ java DataTypeMaximum b=64 s=16384 i=2147483647
 * l=9223372036854775807
 */

// 17D8101002F OnoTakaki 4/17
class Keisan {
    public static void main(String[] av) {
        double m1 = 5.974e24;
        double m2 = 1;
        double r = 6367.447e3;
        double G = 6.67259e-11;
        double f = (G * m1 * m2) / (r * r);
        System.out.println("G=" + G + ", r=" + r + ", m1=" + m1 + ", m2" + m2);
        System.out.println("f=" + f);

    }
}

// 17D8101002F OnoTakaki 4/17
// import java.util.Scanner;
class MinMax {
    public static void main(String[] av) {
        int max = -(1 << 31 - 1);
        int min = (1 << 31 - 1);
        Scanner sc = new Scanner(System.in);
        // System.out.println("max:" + max);
        // System.out.println("min:" + min);
        for (int i = 0; i < 10; i++) {
            int x = sc.nextInt();
            if (max < x) {
                max = x;
            }
            if (min > x) {
                min = x;
            }
        }
        System.out.println("max:" + max);
        System.out.println("min:" + min);
    }
}

// 17D8101002F OnoTakaki 4/17
// import java.util.Scanner;
// import java.io.File;
// import java.io.FileNotFoundException;
// import java.io.IOException;
// import java.io.FileWriter;
// import java.ip.BufferedWriter;
// import java.io.PrintWriter;

class MinMaxFile {
    public static void main(String[] av) throws FileNotFoundException, IOException {
        Scanner sc = new Scanner(new File("test.dat"));
        PrintWriter pw = new PrintWriter("testout.dat");
        int maxim = -(1 << 31 - 1);
        int mini = (1 << 31 - 1);
        for (int i = 0; i < 10; i++) {
            int x;
            x = sc.nextInt();
            maxim = Math.max(x, maxim);
            mini = Math.min(x, mini);
        }
        sc.close();

        pw.println("min:" + mini);
        pw.println("max:" + maxim);
        pw.close();
    }
}