import numpy as np
print(math.ceil(5 / 2))
