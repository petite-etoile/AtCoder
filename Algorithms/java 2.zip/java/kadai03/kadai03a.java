import java.util.Scanner;

class Kadai03_1 {
    public static void printp(long v, int p) {
        if (v < p) {
            System.out.print(v);
        } else {
            // System.out.println(v / p + "" + p);
            printp(v / p, p);
            System.out.print(v % p);
        }
    }

    public static void main(String[] av) {
        Scanner sc = new Scanner(System.in);
        long v = sc.nextLong();
        sc.close();
        System.out.println("10進数:" + v);
        for (int p = 2; p <= 8; p++) {
            System.out.print(p + "進数:");
            printp(v, p);
            System.out.println("");
        }
    }
}

// import java.util.Scanner;
class Kadai03_2 {
    public static void main(String[] av) {
        java.util.Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.close();
        boolean[] p = new boolean[n + 1];

        for (int i = 2; i <= n; i++) {
            p[i] = true;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (p[i]) {
                for (int j = i * 2; j <= n; j += i) {
                    p[j] = false;
                }
            }
        }
        int cnt = 0;
        for (int i = 2; i <= n; i++) {
            if (p[i]) {
                cnt += 1;
            }
        }
        System.out.println(n + "以下の素数の数は" + cnt + "個");
    }
}
