import java.util.Scanner;

class Kadai03_3 {
    static int h, w;
    static int[][] b;

    public static boolean check_square(int i0, int j0, int k) {
        for (int i = i0; i < i0 + k; i++) {
            if (i >= h) {
                return false;
            }
            for (int j = j0; j < j0 + k; j++) {
                if (j >= w) {
                    return false;
                }
                if (b[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] av) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        h = sc.nextInt();
        w = sc.nextInt();
        b = new int[h][w];
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                b[i][j] = sc.nextInt();
            }
        }
        sc.close();
        int kmax = 0;
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                if (b[i][j] == 1) {
                    int k = 1;
                    while (check_square(i, j, k + 1)) {
                        k++;
                    }
                    if (k > kmax) {
                        kmax = k;
                    }
                }
            }
        }
        System.out.println("kmax:" + kmax + " kmax*kmax:" + kmax * kmax);
    }
}

// import java.util.Scanner;
// import
class Kadai03_4 {
    public static void main(String[] av) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        double[][] a = new double[n][n];
        double[][] b = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = sc.nextDouble();
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                b[i][j] = sc.nextDouble();
            }
        }

        double[][] c = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = 0;
                for (int k = 0; k < n; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
    }
}

class Kadai03_3_DP {
    static int H, W;
    static int[][] b;

    public static void main(String[] av) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        H = sc.nextInt();
        W = sc.nextInt();
        b = new int[H][W];

        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                b[i][j] = sc.nextInt();
            }
        }
        sc.close();

        int[][] dp = new int[H][W];
        for (int i = 0; i < H; i++) {
            if (b[i][0] == 1)
                dp[i][0] = 1;
            else
                dp[i][0] = 0;
        }
        for (int j = 0; j < W; j++) {
            if (b[0][j] == 1)
                dp[0][j] = 1;
            else
                dp[0][j] = 0;
        }

        for (int i = 1; i < H; i++) {
            for (int j = 1; j < W; j++) {
                if (b[i][j] == 1)
                    dp[i][j] = Math.min(dp[i - 1][j], Math.min(dp[i - 1][j - 1], dp[i][j - 1])) + 1;
                else
                    dp[i][j] = 0;
            }
        }
        int kmax = 0;
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                kmax = Math.max(kmax, dp[i][j]);
            }
        }
        System.out.println("kmax:" + kmax + " kmax*kmax:" + kmax * kmax);
    }
}
/*
 * McDonalds:kadai03 takaki$ java Kadai03_3_DP 3 3 1 1 1 1 0 0 1 1 1 1
 * McDonalds:kadai03 takaki$ java Kadai03_3_DP 3 3 1 1 1 1 1 0 1 1 1 2
 * McDonalds:kadai03 takaki$ java Kadai03_3_DP 3 3 1 1 1 1 1 1 1 1 1 3
 * McDonalds:kadai03 takaki$ java Kadai03_3_DP 3 3 0 0 0 0 0 0 0 0 0 0
 */